# fitted Launch Plan

> **TEMPLATE — replace the placeholder content below with your actual launch plan.** The structure below is a suggestion; rearrange freely. Once filled in, this is the source of truth Claude should reference when you say "Phase 3 of Week 1" or similar.

## Overview

**Target launch date**: [date]
**Current phase**: [phase + week, e.g. "Week 1, Phase 3"]
**Last updated**: [date — update this whenever the plan changes]

## Week 1 — [theme]

### Phase 1: [name]
**Goal**: [one sentence]
**Status**: [ ] not started / [ ] in progress / [x] done
**Tasks**:
- [ ] Task
- [ ] Task

### Phase 2: [name]
**Goal**: [one sentence]
**Status**: [ ] not started / [ ] in progress / [x] done
**Tasks**:
- [ ] Task

### Phase 3: [name] ← CURRENTLY HERE
**Goal**: [one sentence]
**Status**: in progress
**Tasks**:
- [ ] Task
- [ ] Task

### Phase 4: [name]
**Goal**: [one sentence]
**Status**: not started

## Week 2 — [theme]

[same structure]

## Week 3 — [theme]

[same structure]

## Cross-cutting concerns

Things that touch every phase:

- **Stripe integration**: [where you are in this — currently mid-integration]
- **Design system enforcement**: [status]
- **Social launch readiness**: TikTok ✓ / Instagram ✓ / Threads ✓ / Facebook ✓ / Reddit ✓ / LinkedIn deferred until traction

## Decisions made along the way

Append to this list every time you make a meaningful product/architecture decision. This is what your future self (and Claude) will thank you for.

- [date] — Decided X over Y because Z
- [date] — Decided X over Y because Z

## Open questions

Things you haven't decided yet, parked here so they don't block phase work.

- Question
- Question
